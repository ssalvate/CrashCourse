int main() {
  int a = 42;
  int* a_ptr = &a;
  int b = 100;
  *a_ptr = b;
}
