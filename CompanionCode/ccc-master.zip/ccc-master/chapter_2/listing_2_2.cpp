#include <cstdio>

int main() {
  unsigned int a = 3669732608;
  printf("Yabba %x!\n", a);
  unsigned int b = 69;
  printf("There are %u,%o leaves here.\n", b, b);
}
