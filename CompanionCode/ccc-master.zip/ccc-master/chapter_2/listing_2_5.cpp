#include <cstdio>

int main() {
  bool b1 = true; // b1 is true
  bool b2 = false; // b2 is false
  printf("%d %d\n", b1, b2);
}
